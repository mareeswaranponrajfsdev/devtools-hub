export const environment = {
  production: true,

  emailJs: {
    publicKey: '5tWjjVXUa1zgFL1-B',
    serviceId: 'service_qg2ulee',
    templateId: 'template_k96grnk'
  }
};
