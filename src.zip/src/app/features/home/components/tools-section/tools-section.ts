import { Component } from '@angular/core';

@Component({
  selector: 'app-tools-section',
  imports: [],
  templateUrl: './tools-section.html',
  styleUrl: './tools-section.scss',
})
export class ToolsSection {

}
