import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-why-choose-section',
  imports: [CommonModule],
  templateUrl: './why-choose-section.html',
  styleUrl: './why-choose-section.scss',
})
export class WhyChooseSection {

}
