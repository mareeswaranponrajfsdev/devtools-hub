import { JsonFormatterStore } from './json-formatter.storestore';

describe('JsonFormatterStore', () => {
  it('should create an instance', () => {
    expect(new JsonFormatterStore()).toBeTruthy();
  });
});
