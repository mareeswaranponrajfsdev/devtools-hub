export class JsonError {
}
