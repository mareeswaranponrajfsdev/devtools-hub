export class JsonError {
}
